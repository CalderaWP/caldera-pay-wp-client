<?php


namespace calderawp\CalderaPay\WpClient\CalderaPay;

abstract class Entity extends \calderawp\interop\Entity
{

}
