<?php


namespace calderawp\CalderaPay\WpClient\Contracts;

interface FinderContract
{

}
