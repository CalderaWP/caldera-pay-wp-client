<?php


namespace calderawp\CalderaPay\WpClient\Qualpay;

class Exception extends \calderawp\CalderaPay\WpClient\Exception
{

}
