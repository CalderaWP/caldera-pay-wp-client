<?php


namespace calderawp\CalderaPay\WpClient\Qualpay;

use calderawp\CalderaPay\WpClient\CalderaPay\Entity;

class PaymentRequest extends Entity
{


	public static function fromArray(array $items)
	{
	}
}
