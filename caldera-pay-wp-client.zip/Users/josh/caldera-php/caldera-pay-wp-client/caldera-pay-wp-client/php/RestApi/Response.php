<?php


namespace calderawp\CalderaPay\WpClient\RestApi;

class Response extends \WP_REST_Response
{




}
