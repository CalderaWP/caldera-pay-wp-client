# BrowseSalesRepsData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**user_id** | **int** |  | 
**user_first_name** | **string** | The user&#39;s first name. | [optional] 
**user_last_name** | **string** | The user&#39;s last name. | [optional] 
**user_email** | **string** | The user&#39;s email address. | [optional] 
**user_login** | **string** | This user&#39;s login name to the Qualpay platform. | [optional] 
**usser_id** | **int** | Unique ID assigned by Qualpay to this user. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


