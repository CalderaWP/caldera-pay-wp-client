# GetAppData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**app** | [**\calderaPayQualpayPlatform\Model\ApplicationModel**](ApplicationModel.md) | The details specific to this application. | [optional] 
**pricing** | [**\calderaPayQualpayPlatform\Model\PricingModel**](PricingModel.md) | The pricing available to this application. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


