# Payment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**card_type** | **string** | The two character abbreviation for the card type. | [optional] 
**currency** | **string[]** | An array of currency codes allowed for the specified card type. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


