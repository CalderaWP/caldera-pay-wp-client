# PricingModel

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pricing_id** | **int** | Unique ID assigned by Qualpay to this pricing plan. | [optional] 
**plan** | [**\calderaPayQualpayPlatform\Model\PlanModel**](PlanModel.md) | The pricing plan object. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


