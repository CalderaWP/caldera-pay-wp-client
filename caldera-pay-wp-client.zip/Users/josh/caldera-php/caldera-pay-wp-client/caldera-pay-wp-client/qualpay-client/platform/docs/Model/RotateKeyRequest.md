# RotateKeyRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**minutes** | **int** | The number of minutes the previous key will be valid. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


