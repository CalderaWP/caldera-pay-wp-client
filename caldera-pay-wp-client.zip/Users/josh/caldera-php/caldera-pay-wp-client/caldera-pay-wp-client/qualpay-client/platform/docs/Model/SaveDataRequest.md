# SaveDataRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**\calderaPayQualpayPlatform\Model\ApplicationData[]**](ApplicationData.md) | An array of data fields to save to the application. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


