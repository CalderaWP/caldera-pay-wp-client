# SendInvoiceRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**email_address** | **string[]** | An array of email addresses to which the invoice will be sent. By default, the system will send the invoice to the customer&#39;s email address (business_contact.email_address). | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


